const alpha_constants = {
    ALPHAVANTAGE: 'https://www.alphavantage.co/query?function=',
    ALPHA_VANTAGE_KEY: 'JZH39BS6IQYDES0I'
}